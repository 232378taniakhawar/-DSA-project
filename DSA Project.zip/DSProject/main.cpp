#include <iostream> // For input/output stream operations (e.g., printing messages to the console and reading user input)
#include <fstream> // For file input/output operations (e.g., reading from and writing to files)
#include <unordered_map> // For efficient key-value mapping (used to store chunks of data, edges, etc.)
#include <unordered_set> // For fast lookups and storing unique elements (used for chunk exchange comparison)
#include <string> // For using strings (used for handling text data)
#include <list> // For using doubly linked lists (used to store node information and chunks)
#include <vector> // For dynamic arrays (used for storing chunks and other data that may need resizing)
#include <sstream> // For string stream operations (used to parse strings for user authentication)
#include <stdexcept> // For throwing exceptions (used for error handling in case of empty priority queue)


using namespace std;

// Custom Priority Queue implementation
class CustomPriorityQueue {
private:
    struct Node {
        int priority;
        int value;
        Node* next;
        Node(int p, int v) : priority(p), value(v), next(nullptr) {}
    };

    Node* head;

public:
    CustomPriorityQueue() : head(nullptr) {}

    ~CustomPriorityQueue() {
        while (!isEmpty()) {
            dequeue();
        }
    }

    void enqueue(int priority, int value) {
        Node* newNode = new Node(priority, value);
        if (!head || priority < head->priority) {
            newNode->next = head;
            head = newNode;
        } else {
            Node* temp = head;
            while (temp->next && temp->next->priority <= priority) {
                temp = temp->next;
            }
            newNode->next = temp->next;
            temp->next = newNode;
        }
    }

    int dequeue() {
        if (isEmpty()) {
            throw runtime_error("Priority queue is empty");
        }
        Node* temp = head;
        int value = temp->value;
        head = head->next;
        delete temp;
        return value;
    }

    bool isEmpty() const {
        return head == nullptr;
    }
};

// Helper function: XOR two strings (for encryption and decryption)
string xorStrings(const string& str1, const string& str2) {
    string result = str1;
    for (size_t i = 0; i < str1.size(); ++i) {
        result[i] ^= str2[i % str2.size()];
    }
    return result;
}

// AES-like simple encryption (simplified for demonstration)
class ChunkEncryptor {
private:
    string key; // Encryption key

public:
    // Constructor: Initialize with a key
    ChunkEncryptor(const string& encryptionKey) : key(encryptionKey) {}

    // Encrypt a chunk
    string encrypt(const string& chunk) {
        return xorStrings(chunk, key); // XOR encryption
    }

    // Decrypt a chunk
    string decrypt(const string& encryptedChunk) {
        return xorStrings(encryptedChunk, key); // XOR decryption (same as encryption)
    }
};

class Node {
public:
    int id;
    list<int> chunks; // Chunks as a list

    Node(int nodeId) : id(nodeId) {}
};

class GossipNetwork {
private:
    list<Node> nodes; // Graph represented as an adjacency list of nodes
    unordered_map<int, list<int>> edges; // Edges between nodes
    unordered_map<int, string> chunkData; // Chunk data storage

    void logTransaction(const string& message) {
        ofstream logFile("transactions.txt", ios::app);
        logFile << message << endl;
    }

public:
    GossipNetwork() {
        srand(time(nullptr));
    }

    int getRandom(int min, int max) {
        return min + (rand() % (max - min + 1));
    }

    size_t getNodeCount() const {
        return nodes.size();
    }

    void saveName() {
        ofstream file("transactions.txt");
        file << "New Transaction \n \n" << endl;
    }

    void addNode() {
        nodes.emplace_back(nodes.size());
        logTransaction("Added Node: " + to_string(nodes.back().id));
    }

    void addEdge(int nodeId1, int nodeId2) {
        edges[nodeId1].push_back(nodeId2);
        edges[nodeId2].push_back(nodeId1);
    }

    void addChunk(int chunkId, const string& content, int nodeId) {
        auto it = find_if(nodes.begin(), nodes.end(), [&](const Node& node) { return node.id == nodeId; });
        if (it != nodes.end()) {
            it->chunks.push_back(chunkId);
            chunkData[chunkId] = content;
            logTransaction("Chunk " + to_string(chunkId) + " added to Node " + to_string(nodeId));
        }
    }

    void gossipExchange(int nodeId) {
        auto nodeIt = find_if(nodes.begin(), nodes.end(), [&](const Node& node) { return node.id == nodeId; });
        if (nodeIt == nodes.end() || edges[nodeId].empty()) {
            cout << "Node " << nodeId << " has no peers to perform gossip exchange.\n";
            return;
        }

        for (int peerId : edges[nodeId]) {
            auto peerIt = find_if(nodes.begin(), nodes.end(), [&](const Node& node) { return node.id == peerId; });

            if (peerIt != nodes.end()) {
                // Use sets to temporarily store unique chunks for synchronization
                unordered_set<int> nodeChunks(nodeIt->chunks.begin(), nodeIt->chunks.end());
                unordered_set<int> peerChunks(peerIt->chunks.begin(), peerIt->chunks.end());

                // Identify new chunks to be exchanged
                vector<int> newChunksForPeer, newChunksForNode;
                for (int chunk : peerChunks) {
                    if (nodeChunks.find(chunk) == nodeChunks.end()) {
                        newChunksForNode.push_back(chunk);
                    }
                }
                for (int chunk : nodeChunks) {
                    if (peerChunks.find(chunk) == peerChunks.end()) {
                        newChunksForPeer.push_back(chunk);
                    }
                }

                // Perform the exchange
                for (int chunk : newChunksForPeer) {
                    peerChunks.insert(chunk);
                }
                for (int chunk : newChunksForNode) {
                    nodeChunks.insert(chunk);
                }

                // Update the nodes' chunk lists
                nodeIt->chunks.assign(nodeChunks.begin(), nodeChunks.end());
                peerIt->chunks.assign(peerChunks.begin(), peerChunks.end());

                // Log the exchange
                cout << "Node " << nodeId << " shared chunks with Node " << peerId << ":\n";
                cout << "  Chunks sent to Node " << peerId << ": ";
                for (int chunk : newChunksForPeer) {
                    cout << chunk << " ";
                }
                cout << "\n  Chunks received from Node " << peerId << ": ";
                for (int chunk : newChunksForNode) {
                    cout << chunk << " ";
                }
                cout << "\n";

                logTransaction("Node " + to_string(nodeId) + " exchanged chunks with Node " + to_string(peerId));
            }
        }
    }

    bool isFullySynchronized() const {
        for (const Node& node : nodes) {
            if (node.chunks.size() != chunkData.size()) {
                return false;
            }
        }
        return true;
    }

    void printNetworkStatus() const {
        for (const Node& node : nodes) {
            cout << "Node " << node.id << " has chunks: ";
            for (int chunk : node.chunks) {
                cout << chunk << " ";
            }
            cout << "\n";
        }
    }

    void printDecryptedChunks(int nodeId, ChunkEncryptor& encryptor) const {
        auto it = find_if(nodes.begin(), nodes.end(), [&](const Node& node) { return node.id == nodeId; });
        if (it == nodes.end()) {
            cout << "Invalid node ID.\n";
            return;
        }

        cout << "Node " << it->id << " decrypted chunks:\n";
        CustomPriorityQueue pq;
        for (int chunkId : it->chunks) {
            pq.enqueue(chunkId, chunkId);
        }
        while (!pq.isEmpty()) {
            int chunkId = pq.dequeue();
            string content = chunkData.at(chunkId);
            string decryptedChunk = encryptor.decrypt(content);
            cout << "Chunk ID " << chunkId << " decrypted: " << decryptedChunk << "\n";
        }
    }
};

bool doesUserExist(const string& username) {
    ifstream inFile("users.txt"); // Open file in read mode
    if (inFile.is_open()) {
        string line, existingUsername, existingPassword;
        while (getline(inFile, line)) {
            stringstream ss(line);
            ss >> existingUsername >> existingPassword;
            if (existingUsername == username) {
                return true; // User already exists
            }
        }
        inFile.close();
    }
    return false; // User does not exist
}

void createUser(const string& username, const string& password) {
    if (doesUserExist(username)) {
        cout << "Username already exists. Please choose a different username." << endl;
        return;
    }

    ofstream outFile("users.txt", ios::app); // Open file in append mode
    if (outFile.is_open()) {
        outFile << username << " " << password << "\n"; // Save username and password
        outFile.close();
        cout << "User created successfully!" << endl;
    } else {
        cerr << "Unable to open file for writing." << endl;
    }
}

bool loginUser(const string& username, const string& password) {
    ifstream inFile("users.txt");
    string fileUsername, filePassword;

    if (inFile.is_open()) {
        while (inFile >> fileUsername >> filePassword) {
            if (fileUsername == username && filePassword == password) {
                inFile.close();
                return true; // User found and password matches
            }
        }
        inFile.close();
    } else {
        cerr << "Unable to open file for reading." << endl;
    }

    return false; // If no matching user/password found
}


void first() {
    int choice;
    string username, password;

    cout << endl;
    cout << "----------------------------------------" << endl;
    cout << "Welcome to the Gossip Network Simulator!" << endl;
    cout << "----------------------------------------" << endl;
    cout << endl;
    cout << "Please select an option:" << endl;
    cout << "1.Login \n2.Create User\nEnter choice: ";
    cin >> choice;

    cout << "Enter username: ";
    cin >> username;
    cout << "Enter password: ";
    cin >> password;



    if (choice == 2) {
        createUser(username, password);
        first(); // Recursively call the function to create a new user or login
    } else if (choice == 1) {
        if (loginUser(username, password)) {
            cout << "Login successful!" << endl;
        } else {
            cout << "Login failed. Invalid username or password." << endl;
            first(); // Recursively call the function to create a new user or login
        }
    } else {
        cout << "Invalid choice!" << endl;
        first(); // Recursively call the function to create a new user or login
    }
}


int main() {
    first();
    size_t chunkSize = 20;

    string encryptionKey;
    cout << "Enter the encryption key: ";
    cin >> encryptionKey;
    cin.ignore();  // Clear the newline character left in the input buffer

    string text;
    cout << "Enter the text to be processed(Min 15 words): ";
    getline(cin, text);

    list<pair<int, string>> chunks;
    int keyCounter = 1;
    for (size_t i = 0; i < text.length(); i += chunkSize) {
        string chunk = text.substr(i, chunkSize);
        chunks.emplace_back(keyCounter++, chunk);
    }

    ChunkEncryptor encryptor(encryptionKey);
    GossipNetwork network;

    int nodeCount;
    cout << "Enter the number of Nodes: ";
    cin >> nodeCount;

    for (int i = 0; i < nodeCount; ++i) {
        network.addNode();
    }

    for (int i = 0; i < nodeCount; ++i) {
        for (int j = i + 1; j < nodeCount; ++j) {
            network.addEdge(i, j);
        }
    }

    for (const auto& chunk : chunks) {
        string encryptedChunk = encryptor.encrypt(chunk.second);
        int randomNode = network.getRandom(0, nodeCount - 1);
        network.addChunk(chunk.first, encryptedChunk, randomNode);
    }

    while (!network.isFullySynchronized()) {
        for (int i = 0; i < nodeCount; ++i) {
            network.gossipExchange(i);
        }
        network.printNetworkStatus();
    }

    for (int i = 0; i < nodeCount; ++i) {
        network.printDecryptedChunks(i, encryptor);
    }

    return 0;
}
